import { useEffect, useState } from "react";

// Hero title that is "drawn" letter by letter like ink on drafting paper:
// each letter's outline traces itself, then fills in. Runs on every page load.
// Drawn as SVG so it scales smoothly on desktop, tablet and phone.
const STEP = 0.16; // seconds between the start of each letter

export default function DrawnTitle({ title, location }) {
  const [ready, setReady] = useState(false);

  // Wait for the display font so the outlines are drawn with the right shapes
  useEffect(() => {
    let alive = true;
    const go = () => alive && setReady(true);
    const timer = setTimeout(go, 1500); // never wait longer than this
    (document.fonts ? document.fonts.load("800 100px Syne") : Promise.resolve()).then(go, go);
    return () => { alive = false; clearTimeout(timer); };
  }, []);

  // Split the title over two lines, e.g. "LABOD" / "CONCEPTS"
  const words = title.toUpperCase().split(" ");
  const cut = words.length > 1 ? Math.ceil(words.length / 2) : 1;
  const lines = [words.slice(0, cut).join(" "), words.slice(cut).join(" ")].filter(Boolean);

  const W = Math.max(...lines.map((l) => l.length)) * 88 + 40;
  const H = 85 + (lines.length - 1) * 100 + 15;

  let n = 0; // running letter count, drives the delay of each letter
  const rendered = lines.map((line, li) => (
    <text key={li} x={W / 2} y={85 + li * 100} textAnchor="middle" fill="transparent"
      fontFamily="Syne, sans-serif" fontWeight="800" fontSize="100" letterSpacing="-1">
      {[...line].map((ch, ci) => {
        const delay = n++ * STEP;
        return ch === " " ? (
          <tspan key={ci}> </tspan>
        ) : (
          <tspan key={ci} className={ready ? "draw-letter" : ""} style={{ "--d": `${delay}s` }}>{ch}</tspan>
        );
      })}
    </text>
  ));

  return (
    <>
      <h1>
        <span className="sr-only">{title}</span>
        <svg viewBox={`0 0 ${W} ${H}`} aria-hidden="true"
          className="mx-auto block w-[min(90vw,980px)] overflow-visible">
          {rendered}
        </svg>
      </h1>
      <p className={`mt-5 text-base text-white/90 opacity-0 ${ready ? "fade-up" : ""}`}
        style={{ animationDelay: `${n * STEP + 1}s` }}>
        {location}
      </p>
    </>
  );
}
